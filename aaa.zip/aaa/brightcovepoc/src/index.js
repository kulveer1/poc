import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import SideMenuBar from './components/sideMenuBar';
import ListData from './components/listVideos';
import * as serviceWorker from './serviceWorker';

ReactDOM.render(<div className="d-flex" >
    <SideMenuBar />
    <ListData />
</div>, document.getElementById("wrapper"));
serviceWorker.unregister();
