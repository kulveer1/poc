import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import axios from 'axios';
import TableData from './tableData';
import '../css/sideBar.css';
import 'react-toastify/dist/ReactToastify.css';

class ListVideo extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            selectedFile: null,
            loaded: 0
        }
    }

    fileSelectedHandler = event => {
        var files = event.target.files[0];
        console.log(files)
        this.setState({
            selectedFile: files,
            loaded: 0
        })

    }
    fileUploadHandler = (e) => {
        e.preventDefault();
        const fd = new FormData();
        fd.append("file", this.state.selectedFile, this.state.selectedFile.name)

        axios.post("http://localhost:5000/upload", fd).then(res => {
            console.log('---------upload success-----------')
            return;
        }).catch(err => { console.log('--------upload failed--------' + err) })
    }



    render() {
        return (

            <React.Fragment>
                <div id="main-content">
                    <div className="container-fluid">
                        <h1 className="mt-4">Assets</h1>
                        <table className="table table-bordered table-striped" >
                            <thead style={{ backgroundColor: "#91daf7" }}>
                                <tr>
                                    <th>#</th>
                                    <th>Name</th>
                                    <th>Size</th>
                                    <th>Type</th>
                                </tr>
                            </thead>
                            <tbody>
                                <TableData />
                            </tbody>
                        </table>
                        <hr></hr>

                        <form className='form-group'>
                            <table>
                                <tbody>
                                    <tr>
                                        <td>
                                            <div className="file-field">
                                                <div className="btn btn-sm float-left">
                                                    <input type="file" name="file" onChange={this.fileSelectedHandler} />
                                                </div>
                                            </div>
                                        </td>
                                        <td>{/*
                                                <div className="form-group">
                                                    <ToastContainer />
                                                    <Progress max="100" color="success" value={this.state.loaded} >{Math.round(this.state.loaded, 2)}%</Progress>
                                                </div>*/}

                                            <button type="submit" className="btn btn-primary" onClick={this.fileUploadHandler} >Upload</button>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </form>
                        <hr></hr>
                    </div>
                </div>
            </React.Fragment>
        );

    }
}
export default ListVideo;