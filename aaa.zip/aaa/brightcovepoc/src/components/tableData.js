import React from "react";
import { BrowserRouter as Router, Route, Link } from 'react-router-dom';
import data from "../uploaded_files/video_det";
var videoList = data.assets;

class TableData extends React.Component {
    render() {
        return (
            <Router>
                <React.Fragment>
                    {videoList.map(function (assets, i) {
                        return <tr key={i++}>
                            <td>{i}</td>
                            <td>
                                <Link to="#showDetails">{assets.Name}</Link>
                                <Route path="" Component=""></Route>
                            </td>
                            <td>{assets.Size} MB </td>
                            <td>{assets.Type}</td>
                        </tr>
                    })
                    }
                </React.Fragment>
            </Router >
        )
    }
}
export default TableData;