import React from "react";
import { BrowserRouter as Router, Route, Link } from 'react-router-dom';
import "bootstrap/dist/css/bootstrap.min.css";
import '../css/sideBar.css';

class SideMenuBar extends React.Component {
  render() {
    var ing_count = 1;
    var err_count = 0;
    var live_count = 3;
    return <Router>
      <React.Fragment>
        <div className="bg-light border-right" id="sidebar">
          <div className="sidebar-heading" style={{ backgroundColor: "#91daf7" }}>Menu</div>
          <div className="list-group list-group-flush" >
            <Link to="#Ingested" className="list-group-item list-group-item-action bg-light">Ingested ({ing_count})</Link>
            <Link to="#Ingested" className="list-group-item list-group-item-action bg-light">InProgress ({ing_count})</Link>
            <Link to="#Error" className="list-group-item list-group-item-action bg-light">Error ({err_count})</Link>
            <Link to="#Live" className="list-group-item list-group-item-action bg-light">Completed/Transcoded ({live_count})</Link>
            <Route to="#Ingested" component=""></Route>
            <Route to="#Error" component=""></Route>
            <Route to="#Live" component=""></Route>
          </div>
        </div>
      </React.Fragment>
    </Router >
  }
}
export default SideMenuBar;
