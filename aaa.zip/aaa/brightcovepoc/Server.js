const express = require('express');
const fileUpload = require('express-fileupload');
const app = express();
var ffmpeg = require('fluent-ffmpeg');
const path = require('path');
app.use(fileUpload());
const fs = require('fs')
rdata = { assets:[] }
var rdata = fs.readFileSync('src/uploaded_files/video_det.json');
var words = JSON.parse(rdata);
var details = "video_det";

/*
var data = {
    'Name': req.file.filename,
    'Size': req.file.size,
    'Type': req.file.mimetype,
    'Destination': req.file.destination,
    'Path': req.file.path
};
*/

ffmpeg.setFfmpegPath("C:/Users/kulveer.kaur01/Desktop/ffmpeg/bin/ffmpeg.exe")
//------------------------------------------------------------------------------
//post request
app.post('/upload', (req, res) => {
    if (req.files === null) {
        return res.status(400).json({ msg: "no file" });
    }
    const file = req.files.file;
    file.mv(`${__dirname}/public/uploaded_files/${file.name}`, err => {
        if (err) {
            console.log(err);
            return res.status(500).send(err)
        }
    });
    /////////////////////////////////////////////////////////////////
    var data = { 'Name': file.name, 'Size': file.size, 'Type': file.mimetype, 'Destination': file.tempFilePath, 'Path': file.tempFilePath };
    //var obj = { assets: [] };
    words.assets.push(data);
    json_data = JSON.stringify(words) + "\n";
    fs.writeFile("src/uploaded_files/" + details + ".json", json_data, (err) => { //appendFile // writeFile
        if (err) { console.log(err); }
        console.log("Successfully Written to File.");
    });
    ///////////////////////////////////////////////////////////////

    function consoleEncode(fn) {
        // height, bitrate
        const sizes = [
            [240, 350],
            [480, 700],
            [720, 2500],
        ];
        const fallback = [480, 400];

        let name = path.basename(fn, path.extname(fn));
        const targetdir = path.join(`${__dirname}/public`, name);
        const sourcefn = path.resolve(fn);

        console.log('source', sourcefn);
        console.log('info', sizes);
        console.log('info', targetdir);

        try {
            var targetdirInfo = fs.statSync(targetdir);
        } catch (err) {
            if (err.code === 'ENOENT') {
                fs.mkdirSync(targetdir);
            } else {
                throw err;
            }
        }

        var proc = ffmpeg({
            source: sourcefn,
            cwd: targetdir
        });

        var targetfn = path.join(targetdir, `${name}.m3u8`);

        proc
            .output(targetfn)
            .format('dash')
            .videoCodec('libx264')
            .audioCodec('aac')
            .audioChannels(2)
            .audioFrequency(44100)
            .outputOptions([
                '-preset veryfast',
                '-keyint_min 60',
                '-g 60',
                '-sc_threshold 0',
                '-profile:v main',
                '-use_template 1',
                '-use_timeline 1',
                '-b_strategy 0',
                '-bf 1',
            ]);

        for (var size of sizes) {
            let index = sizes.indexOf(size);

            proc
                .outputOptions([
                    `-filter_complex [0]format=pix_fmts=yuv420p[temp${index}];[temp${index}]scale=-2:${size[0]}[A${index}]`,
                    `-map [A${index}]:v`,
                    `-b:v:${index} ${size[1]}k`,
                ]);
        }

        //Fallback version
        proc
            .output(path.join(targetdir, `${name}.mp4`))
            .format('mp4')
            .videoCodec('libx264')
            .videoBitrate(fallback[1])
            .size(`?x${fallback[0]}`)
            .audioCodec('aac')
            .audioChannels(2)
            .audioFrequency(44100)
            .audioBitrate(128)
            .outputOptions([
                '-preset veryfast',
                '-movflags +faststart',
                '-keyint_min 60',
                '-refs 5',
                '-g 60',
                '-pix_fmt yuv420p',
                '-sc_threshold 0',
                '-profile:v main',
            ]);

        proc.on('start', function (commandLine) {
            console.log('progress', 'Spawned Ffmpeg with command: ' + commandLine);
        });

        proc.on('progress', function (info) {
            console.log('progress', info);
        })
            .on('end', function () {
                console.log('complete');
            })
            .on('error', function (err) {
                console.log('error', err);
            });
        return proc.run();
    }
    consoleEncode(`${__dirname}/public/uploaded_files/${file.name}`);

});

app.listen(5000, () => console.log("listening...."));
